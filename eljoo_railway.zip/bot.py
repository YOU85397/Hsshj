
import telebot
import json
import os

BOT_TOKEN = os.getenv('BOT_TOKEN')
bot = telebot.TeleBot(BOT_TOKEN)

المستخدمين_مفعلين = set()
كلمة_السر = "853974"

آخر_رسالة = {
    "chat_id": None,
    "message_id": None
}

file_path = "channels.json"
if os.path.exists(file_path):
    with open(file_path, "r") as f:
        القنوات_المحفوظة = json.load(f)
else:
    القنوات_المحفوظة = {}

def حفظ_معرف_قناة(المعرف):
    if المعرف not in القنوات_المحفوظة.values():
        الرقم = str(len(القنوات_المحفوظة) + 1)
        القنوات_المحفوظة[الرقم] = المعرف
        with open(file_path, "w") as f:
            json.dump(القنوات_المحفوظة, f, ensure_ascii=False, indent=2)

@bot.message_handler(commands=['start'])
def البداية(message):
    if message.from_user.id in المستخدمين_مفعلين:
        متابعة_البداية(message)
    else:
        msg = bot.send_message(message.chat.id, "أدخل كلمة السر:")
        bot.register_next_step_handler(msg, تحقق_كلمة_السر)

def تحقق_كلمة_السر(message):
    if message.text.strip() == كلمة_السر:
        المستخدمين_مفعلين.add(message.from_user.id)
        bot.send_message(message.chat.id, "كلمة السر صحيحة! يمكنك الآن استخدام البوت.")
        متابعة_البداية(message)
    else:
        bot.send_message(message.chat.id, "كلمة السر غير صحيحة، حاول مرة أخرى.")

def متابعة_البداية(message):
    msg = bot.send_message(message.chat.id, "اكتب معرف القناة (مثال: @mychannel):")
    bot.register_next_step_handler(msg, استلام_المعرف)

@bot.message_handler(func=lambda m: False)
def استلام_المعرف(message):
    معرف_القناة = message.text.strip()
    msg = bot.send_message(message.chat.id, "اكتب النص الذي تريد نشره:")
    bot.register_next_step_handler(msg, استلام_النص, معرف_القناة)

def استلام_النص(message, المعرف):
    النص = message.text.strip()
    msg = bot.send_message(message.chat.id, "اكتب نص الزر:")
    bot.register_next_step_handler(msg, استلام_نص_الزر, المعرف, النص)

def استلام_نص_الزر(message, المعرف, النص):
    نص_الزر = message.text.strip()
    msg = bot.send_message(message.chat.id, "أرسل الرابط الذي سيفتح عند الضغط على الزر:")
    bot.register_next_step_handler(msg, إرسال, المعرف, النص, نص_الزر)

def إرسال(message, المعرف, النص, نص_الزر):
    الرابط = message.text.strip()
    markup = telebot.types.InlineKeyboardMarkup()
    button = telebot.types.InlineKeyboardButton(text=نص_الزر, url=الرابط)
    markup.add(button)

    sent = bot.send_message(chat_id=المعرف, text=النص, reply_markup=markup)
    آخر_رسالة["chat_id"] = المعرف
    آخر_رسالة["message_id"] = sent.message_id

    حفظ_معرف_قناة(المعرف)
    bot.send_message(message.chat.id, "تم نشر الرسالة في القناة!")

bot.polling(none_stop=True)
